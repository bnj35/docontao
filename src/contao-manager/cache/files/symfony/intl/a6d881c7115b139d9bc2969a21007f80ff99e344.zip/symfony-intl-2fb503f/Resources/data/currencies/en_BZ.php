<?php

return [
    'Names' => [
        'BZD' => [
            '$',
            'Belize Dollar',
        ],
    ],
];
