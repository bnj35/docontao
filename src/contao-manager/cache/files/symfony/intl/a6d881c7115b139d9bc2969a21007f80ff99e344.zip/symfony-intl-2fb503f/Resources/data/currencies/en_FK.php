<?php

return [
    'Names' => [
        'FKP' => [
            '£',
            'Falkland Islands Pound',
        ],
        'GBP' => [
            'GB£',
            'British Pound',
        ],
    ],
];
