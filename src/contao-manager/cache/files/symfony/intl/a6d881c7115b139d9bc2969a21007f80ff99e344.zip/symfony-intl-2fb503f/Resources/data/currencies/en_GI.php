<?php

return [
    'Names' => [
        'GBP' => [
            'GB£',
            'British Pound',
        ],
        'GIP' => [
            '£',
            'Gibraltar Pound',
        ],
    ],
];
