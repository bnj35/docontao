<?php

return [
    'Names' => [
        'IDR' => [
            'Rp',
            'Indonesian Rupiah',
        ],
    ],
];
