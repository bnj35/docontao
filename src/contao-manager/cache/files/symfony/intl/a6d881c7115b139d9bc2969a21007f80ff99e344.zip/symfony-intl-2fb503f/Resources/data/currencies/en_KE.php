<?php

return [
    'Names' => [
        'KES' => [
            'Ksh',
            'Kenyan Shilling',
        ],
    ],
];
