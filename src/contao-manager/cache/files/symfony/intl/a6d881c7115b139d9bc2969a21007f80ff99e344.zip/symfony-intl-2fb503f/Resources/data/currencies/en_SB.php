<?php

return [
    'Names' => [
        'SBD' => [
            '$',
            'Solomon Islands Dollar',
        ],
    ],
];
