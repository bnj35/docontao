<?php

return [
    'Names' => [
        'BOB' => [
            'Bs',
            'boliviano',
        ],
    ],
];
