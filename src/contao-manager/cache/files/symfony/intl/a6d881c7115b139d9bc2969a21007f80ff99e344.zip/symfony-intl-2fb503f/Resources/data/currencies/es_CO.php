<?php

return [
    'Names' => [
        'COP' => [
            '$',
            'peso colombiano',
        ],
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
    ],
];
