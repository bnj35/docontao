<?php

return [
    'Names' => [
        'BDT' => [
            'BDT',
            'taka bangladesí',
        ],
        'BTN' => [
            'BTN',
            'ngultrum butanés',
        ],
        'KGS' => [
            'KGS',
            'som kirguís',
        ],
        'KHR' => [
            'KHR',
            'riel camboyano',
        ],
        'LAK' => [
            'LAK',
            'kip laosiano',
        ],
        'MRO' => [
            'MRU',
            'uguiya (1973–2017)',
        ],
        'MRU' => [
            'UM',
            'uguiya',
        ],
        'MVR' => [
            'MVR',
            'rupia de Maldivas',
        ],
        'MXN' => [
            '$',
            'peso mexicano',
        ],
        'STN' => [
            'STN',
            'dobra santotomense',
        ],
        'THB' => [
            'THB',
            'baht tailandés',
        ],
        'VND' => [
            'VND',
            'dong vietnamita',
        ],
        'ZMW' => [
            'ZMW',
            'kwacha zambiano',
        ],
    ],
];
