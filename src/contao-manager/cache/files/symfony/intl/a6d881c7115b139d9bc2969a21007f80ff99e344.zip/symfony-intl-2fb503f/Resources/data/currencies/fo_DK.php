<?php

return [
    'Names' => [
        'DKK' => [
            'kr.',
            'donsk króna',
        ],
    ],
];
