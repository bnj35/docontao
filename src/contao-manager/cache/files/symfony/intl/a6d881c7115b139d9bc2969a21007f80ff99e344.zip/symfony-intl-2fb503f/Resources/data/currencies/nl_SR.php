<?php

return [
    'Names' => [
        'SRD' => [
            '$',
            'Surinaamse dollar',
        ],
    ],
];
