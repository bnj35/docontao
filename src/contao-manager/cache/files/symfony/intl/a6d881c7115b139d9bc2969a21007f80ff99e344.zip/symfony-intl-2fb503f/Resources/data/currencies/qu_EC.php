<?php

return [
    'Names' => [
        'PEN' => [
            'PEN',
            'Sol Peruano',
        ],
        'USD' => [
            '$',
            'Dólar Americano',
        ],
    ],
];
