<?php

return [
    'Names' => [
        'BRL' => [
            'R$',
            'Real bu Bresil',
        ],
        'CNY' => [
            'CN¥',
            'Yuan bu Siin',
        ],
        'EUR' => [
            '€',
            'Euro',
        ],
        'GBP' => [
            '£',
            'Pound bu Grànd Brëtaañ',
        ],
        'INR' => [
            '₹',
            'Rupee bu End',
        ],
        'JPY' => [
            'JP¥',
            'Yen bu Sapoŋ',
        ],
        'RUB' => [
            'RUB',
            'Ruble bi Rsis',
        ],
        'USD' => [
            '$',
            'Dolaaru US',
        ],
        'XOF' => [
            'F CFA',
            'Franc CFA bu Afrik Sowwu-jant',
        ],
    ],
];
