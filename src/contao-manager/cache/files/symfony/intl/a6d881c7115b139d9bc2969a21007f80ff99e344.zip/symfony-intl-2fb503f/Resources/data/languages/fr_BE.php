<?php

return [
    'Names' => [
        'frp' => 'franco-provençal',
        'goh' => 'ancien haut-allemand',
        'gu' => 'gujarati',
        'njo' => 'ao',
    ],
    'LocalizedNames' => [],
];
